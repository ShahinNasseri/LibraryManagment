import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'hp-dashboard-builder-main',
  templateUrl: './dashboard-builder-main.component.html',
  styleUrls: ['./dashboard-builder-main.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardBuilderMainComponent {
  
}
